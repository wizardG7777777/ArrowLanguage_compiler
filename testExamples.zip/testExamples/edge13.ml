function sum a b
	return a + b
print sum(1,2,3)
