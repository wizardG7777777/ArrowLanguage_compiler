# 3.500000 is printed
print 3.5
