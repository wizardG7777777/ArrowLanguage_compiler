x <--11
y <- 12
print x + y
