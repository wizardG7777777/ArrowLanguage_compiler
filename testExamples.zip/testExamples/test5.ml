function average a b 
	return (a + b) / 2
x <- 10
y <- 20
print average(x,y)
