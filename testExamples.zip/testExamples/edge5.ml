function a 

