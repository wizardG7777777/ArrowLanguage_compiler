#less 1 return data
function add a b
	return a + b
print add(10)
