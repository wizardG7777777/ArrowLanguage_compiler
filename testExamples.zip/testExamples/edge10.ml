function add a b 
	return a + b
print add(10,add(10,))
