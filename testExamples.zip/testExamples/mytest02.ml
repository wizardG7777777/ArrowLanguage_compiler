print arg0+arg1
