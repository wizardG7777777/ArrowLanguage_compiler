x <--10
y <- 10
print x + y

