# re_assignment of variables
x <- 5 
print x
x <- 10
print x
