# 18 is printed
#
function printsum a b
	print a + b
#
printsum (12, 6)
