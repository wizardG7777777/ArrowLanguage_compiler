a<-1
aa<-1
aaa<-1
aaaa<-1
aaaaa<-1
print a+aa+aaa+aaaa+aaaaa
