# should be 0.0
y <- x * 5
print y
