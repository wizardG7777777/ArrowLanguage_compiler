a <- 1
b <- a - 1
print b
