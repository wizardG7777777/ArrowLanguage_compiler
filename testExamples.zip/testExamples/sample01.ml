# an assignment statement, nothing is printed
x <- 2.3
