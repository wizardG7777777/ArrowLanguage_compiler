function square n
	return n * n 
value <- 6
print square(value)
