averylongvar <- 9.9
x <- 0.1
print averylongvar+x
