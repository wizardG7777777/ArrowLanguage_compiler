# 50 is printed
#
function multiply a b
	x <- a * b
	return x
#
print multiply(10, 5)
