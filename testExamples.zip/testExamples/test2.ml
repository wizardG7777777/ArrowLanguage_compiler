function add a b 
	return a + b 

function multiply a b
	return a * b
print multiply(add(2,3),4)
