# 9 is printed
#
one <- 1
#
function increment value
	return value + one
#
print increment(3) + increment(4)
