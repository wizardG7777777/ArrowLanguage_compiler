# 24 is printed
x <- 8
y <- 3
print x * y
