# no return
function x
	a <- a + 1
	return a 
print x()
