# an assignment statement, 2.500000 is printed
x <- 2.5
print x
