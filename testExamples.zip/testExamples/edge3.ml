x <- a
print x
