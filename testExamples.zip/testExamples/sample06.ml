# 72 is printed
#
function multiply a b
	return a * b
#
print multiply(12, 6)
