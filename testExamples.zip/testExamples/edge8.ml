print a
